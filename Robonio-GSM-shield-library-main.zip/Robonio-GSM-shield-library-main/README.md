# Robonio-GSM-shield-library

![gsm-shield](https://user-images.githubusercontent.com/77489853/185864142-f3fdb216-7dd6-45c9-9334-c0466a1c26a3.jpg)

Robonio.start(); Initializes the GSM shield

Robonio.callAnswer();  used to answer incoming call
